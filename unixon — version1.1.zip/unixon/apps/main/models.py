from django.db import models
from django.contrib.auth.models import User
import datetime
from django.utils import timezone
# Create your models here.
class Article(models.Model):
    art_title = models.CharField('Название статьи', max_length = 200)
    art_content = models.TextField('Текст статьи')
    pub_date = models.DateTimeField('Дата публикации')



    def was_published_recently(self):
        return self.pub_date >= (timezone.now() - datetime.timedelta(days = 5))

    class Meta:
        verbose_name = 'Статья'
        verbose_name_plural = 'Статьи'

class Comment(models.Model):
    article = models.ForeignKey(Article, on_delete = models.CASCADE)
    name_user =  models.ForeignKey(User, verbose_name = 'Пользователь', on_delete = models.SET_NULL, null = True)
    comment_text = models.CharField('Текст коментария', max_length = 300)

    class Meta:
        verbose_name = 'Комментарий'
        verbose_name_plural = 'Комментарии'